import { asd } from './func';

asd();
