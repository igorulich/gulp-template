* npx stylelint "**/*.scss"
* npx stylelint "**/*.scss" --fix
